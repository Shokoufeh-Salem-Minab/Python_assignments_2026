import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def calculate_revenue(quantity, price):
    """Return the revenue for a sale."""
    return quantity * price


def get_top_product(data):
    """Return the product with the highest total revenue."""
    revenue_by_product = data.groupby("Product")["Total_Sales"].sum()
    return revenue_by_product.idxmax()


def main():
    # Read the sales data from the CSV file.
    df = pd.read_csv("sales.csv")

    print("\n========== SALES DATA ANALYSIS ==========")

    # PART 2: PYTHON AND NUMPY
    print("\n--- PART 2: PYTHON AND NUMPY ---")

    # Store product names in a Python list.
    products = df["Product"].tolist()
    print("Product names:", products)

    # Create a dictionary with the total quantity sold for each product.
    quantity_by_product = (
        df.groupby("Product")["Quantity"].sum().to_dict()
    )
    print("\nQuantity sold by product:")
    print(quantity_by_product)

    # Put all quantities into a NumPy array.
    quantities = np.array(df["Quantity"])

    print("\nTotal quantity sold:", np.sum(quantities))
    print("Average quantity sold:", round(np.mean(quantities), 2))
    print("Maximum quantity:", np.max(quantities))
    print("Minimum quantity:", np.min(quantities))
    print("Standard deviation:", round(np.std(quantities), 2))

    # Find the row positions where more than 5 items were sold.
    indexes = np.where(quantities > 5)[0]
    print("Indexes where quantity is greater than 5:", indexes)

    # PART 3: PANDAS
    print("\n--- PART 3: PANDAS ---")

    print("\nFirst five rows:")
    print(df.head())

    print("\nDataset information:")
    df.info()

    print("\nDescriptive statistics:")
    print(df.describe())

    # Calculate revenue for each sales record.
    df["Total_Sales"] = df.apply(
        lambda row: calculate_revenue(row["Quantity"], row["Price"]),
        axis=1
    )

    total_revenue = df["Total_Sales"].sum()
    print("\nTotal revenue:", total_revenue)

    # Find the product with the highest total revenue.
    top_product = get_top_product(df)
    product_revenue = df.groupby("Product")["Total_Sales"].sum()
    print("Product with the highest revenue:", top_product)
    print("Revenue from this product:", product_revenue[top_product])

    # Calculate revenue for each category.
    category_revenue = df.groupby("Category")["Total_Sales"].sum()
    print("\nRevenue by category:")
    print(category_revenue)

    # Find the region with the highest revenue.
    region_revenue = df.groupby("Region")["Total_Sales"].sum()
    best_region = region_revenue.idxmax()
    print("\nRevenue by region:")
    print(region_revenue)
    print("Best-performing region:", best_region)

    # Sort the rows from highest to lowest sales revenue.
    df = df.sort_values(by="Total_Sales", ascending=False)

    # Save the updated data.
    df.to_csv("updated_sales.csv", index=False)
    print("\nUpdated data saved to updated_sales.csv")

    # PART 4: DATA VISUALIZATION

    # Bar chart: total revenue for each product.
    plt.figure(figsize=(9, 5))
    product_revenue.sort_values(ascending=False).plot(kind="bar")
    plt.title("Total Revenue by Product")
    plt.xlabel("Product")
    plt.ylabel("Total Revenue")
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    plt.savefig("bar_chart.png", dpi=150)
    plt.close()

    # Pie chart: percentage of revenue from each category.
    plt.figure(figsize=(7, 7))
    category_revenue.plot(
        kind="pie",
        autopct="%1.1f%%",
        startangle=90
    )
    plt.title("Revenue Percentage by Category")
    plt.ylabel("")
    plt.tight_layout()
    plt.savefig("pie_chart.png", dpi=150)
    plt.close()

    # Histogram: distribution of revenue for individual sales records.
    plt.figure(figsize=(9, 5))
    plt.hist(df["Total_Sales"], bins=8, edgecolor="black")
    plt.title("Distribution of Sales Revenue")
    plt.xlabel("Revenue per Sales Record")
    plt.ylabel("Number of Sales Records")
    plt.tight_layout()
    plt.savefig("histogram.png", dpi=150)
    plt.close()

    # PART 5: WRITE THE ANALYSIS
    top_category = category_revenue.idxmax()
    best_region_revenue = region_revenue[best_region]

    analysis = f"""SALES DATA ANALYSIS
Student: Davud Jepbarbergenov

1. Which product generated the highest revenue?

{top_product} generated the highest total revenue:
{product_revenue[top_product]:.2f}.

2. Which category generated the most revenue?

{top_category} generated the most revenue:
{category_revenue[top_category]:.2f}.

3. Which region performed best?

{best_region} performed best, with total revenue of
{best_region_revenue:.2f}.

4. What can you conclude from your analysis?

The dataset contains {len(df)} sales records and the total revenue is
{total_revenue:.2f}. {top_product} is the product with the highest
revenue, while {top_category} is the strongest category.
{best_region} is the region with the highest revenue.

This project shows how Python, NumPy and Pandas can be used to
organize sales data, calculate statistics and compare results.
Matplotlib charts make the results easier to understand.
"""

    with open("analysis.txt", "w", encoding="utf-8") as file:
        file.write(analysis)

    print("\nAnalysis saved to analysis.txt")
    print("\nThree charts were saved:")
    print("bar_chart.png, pie_chart.png, histogram.png")
    print("\nProject completed successfully!")


if __name__ == "__main__":
    main()
