# HW7 - Sales Data Analysis

Student: Davud Jepbarbergenov

## Files
- `sales.csv`: original dataset with 15 sales records.
- `main.py`: complete analysis program.
- `updated_sales.csv`: dataset with the calculated `Total_Sales` column, sorted by revenue.
- `analysis.txt`: written answers to the four interpretation questions.
- `bar_chart.png`: total revenue by product.
- `pie_chart.png`: revenue percentage by category.
- `histogram.png`: distribution of revenue per sales record.

## Run the project
Install the required libraries:

```bash
python -m pip install pandas numpy matplotlib
```

Run the program from this folder:

```bash
python main.py
```

The program reads `sales.csv` and creates the updated CSV, analysis text file and three charts.
