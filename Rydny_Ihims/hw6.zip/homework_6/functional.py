from functools import reduce

students = [
    {"name": "Anna", "exam1": 85, "exam2": 90, "exam3": 88, "homework": 9},
    {"name": "Peter", "exam1": 55, "exam2": 60, "exam3": 58, "homework": 6},
    {"name": "Maria", "exam1": 95, "exam2": 92, "exam3": 98, "homework": 10},
    {"name": "John", "exam1": 70, "exam2": 65, "exam3": 72, "homework": 8},
    {"name": "Sofia", "exam1": 40, "exam2": 50, "exam3": 45, "homework": 5},
    {"name": "David", "exam1": 88, "exam2": 91, "exam3": 86, "homework": 10}
]


def exam_average(s):
    return (s["exam1"] + s["exam2"] + s["exam3"]) / 3


def homework_score(s):
    return s["homework"] / 10 * 100


def final_score(s):
    return 0.7 * exam_average(s) + 0.3 * homework_score(s)


def get_status(score):
    return "Pass" if score >= 60 else "Fail"


def is_excellent(s):
    return all(s[e] >= 90 for e in ["exam1", "exam2", "exam3"])


def add_results(s):
    # new dict, original data is not changed
    score = final_score(s)
    return {**s, "final": score, "status": get_status(score)}


def add_recovery(s):
    return {**s, "recovery": min(s["final"] + 5, 100)}


results = list(map(add_results, students))
passed = list(filter(lambda s: s["status"] == "Pass", results))
failed = list(filter(lambda s: s["status"] == "Fail", results))
excellent = list(filter(is_excellent, results))
recovery = list(map(add_recovery, failed))
total = reduce(lambda acc, s: acc + s["final"], results, 0)
ranked = sorted(results, key=lambda s: s["final"], reverse=True)

print("Final scores:")
list(map(lambda s: print(f"{s['name']}: {s['final']:.2f} ({s['status']})"), results))

print("\nPassed:", [s["name"] for s in passed])
print("Failed:", [s["name"] for s in failed])
print("Excellent:", [s["name"] for s in excellent])

print("\nRecovery scores:")
list(map(lambda s: print(f"{s['name']}: {s['recovery']:.2f} (status stays {s['status']})"), recovery))

print(f"\nTotal final score: {total:.2f}")
print(f"Class average: {total / len(results):.2f}")

print("\nRanking:")
for i, s in enumerate(ranked, 1):
    print(f"{i}. {s['name']} - {s['final']:.2f}")
