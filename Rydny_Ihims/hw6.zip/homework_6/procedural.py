students = [
    {"name": "Anna", "exam1": 85, "exam2": 90, "exam3": 88, "homework": 9},
    {"name": "Peter", "exam1": 55, "exam2": 60, "exam3": 58, "homework": 6},
    {"name": "Maria", "exam1": 95, "exam2": 92, "exam3": 98, "homework": 10},
    {"name": "John", "exam1": 70, "exam2": 65, "exam3": 72, "homework": 8},
    {"name": "Sofia", "exam1": 40, "exam2": 50, "exam3": 45, "homework": 5},
    {"name": "David", "exam1": 88, "exam2": 91, "exam3": 86, "homework": 10}
]


def exam_average(s):
    return (s["exam1"] + s["exam2"] + s["exam3"]) / 3


def homework_score(s):
    return s["homework"] / 10 * 100


def final_score(s):
    return 0.7 * exam_average(s) + 0.3 * homework_score(s)


def get_status(score):
    if score >= 60:
        return "Pass"
    return "Fail"


def is_excellent(s):
    return s["exam1"] >= 90 and s["exam2"] >= 90 and s["exam3"] >= 90


def recovery_score(score):
    return min(score + 5, 100)


results = []
for s in students:
    score = final_score(s)
    results.append({"name": s["name"], "final": score, "status": get_status(score)})

print("Final scores:")
for r in results:
    print(f"{r['name']}: {r['final']:.2f} ({r['status']})")

print("\nExcellent students:")
for s in students:
    if is_excellent(s):
        print(s["name"])

print("\nRecovery scores:")
for r in results:
    if r["final"] < 60:
        print(f"{r['name']}: {recovery_score(r['final']):.2f} (status stays {r['status']})")

total = 0
for r in results:
    total += r["final"]
print(f"\nClass average: {total / len(results):.2f}")

# rank by final score, highest first
ranked = sorted(results, key=lambda r: r["final"], reverse=True)
print("\nRanking:")
rank = 1
for r in ranked:
    print(f"{rank}. {r['name']} - {r['final']:.2f}")
    rank += 1
