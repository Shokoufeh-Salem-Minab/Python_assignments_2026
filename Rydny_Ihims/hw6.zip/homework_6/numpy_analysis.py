import numpy as np

students = [
    {"name": "Anna", "exam1": 85, "exam2": 90, "exam3": 88, "homework": 9},
    {"name": "Peter", "exam1": 55, "exam2": 60, "exam3": 58, "homework": 6},
    {"name": "Maria", "exam1": 95, "exam2": 92, "exam3": 98, "homework": 10},
    {"name": "John", "exam1": 70, "exam2": 65, "exam3": 72, "homework": 8},
    {"name": "Sofia", "exam1": 40, "exam2": 50, "exam3": 45, "homework": 5},
    {"name": "David", "exam1": 88, "exam2": 91, "exam3": 86, "homework": 10}
]

names = np.array([s["name"] for s in students])
exams = np.array([[s["exam1"], s["exam2"], s["exam3"]] for s in students])
homework = np.array([s["homework"] for s in students])

student_avg = exams.mean(axis=1)
final = 0.7 * student_avg + 0.3 * (homework / 10 * 100)

print("Exam scores:\n", exams)
print("\nStudent averages:", np.round(student_avg, 2))
print("Final scores:", np.round(final, 2))

print("\nExam stats (exam1, exam2, exam3):")
print("Mean:", np.round(exams.mean(axis=0), 2))
print("Max:", exams.max(axis=0))
print("Min:", exams.min(axis=0))
print("Std:", np.round(exams.std(axis=0), 2))

# boolean mask
mask = student_avg >= 85
print("\nStudents with exam average >= 85:", names[mask])
