import pandas as pd

students = [
    {"name": "Anna", "exam1": 85, "exam2": 90, "exam3": 88, "homework": 9},
    {"name": "Peter", "exam1": 55, "exam2": 60, "exam3": 58, "homework": 6},
    {"name": "Maria", "exam1": 95, "exam2": 92, "exam3": 98, "homework": 10},
    {"name": "John", "exam1": 70, "exam2": 65, "exam3": 72, "homework": 8},
    {"name": "Sofia", "exam1": 40, "exam2": 50, "exam3": 45, "homework": 5},
    {"name": "David", "exam1": 88, "exam2": 91, "exam3": 86, "homework": 10}
]

df = pd.DataFrame(students)

df["exam_average"] = df[["exam1", "exam2", "exam3"]].mean(axis=1).round(2)
df["homework_score"] = df["homework"] / 10 * 100
df["final_score"] = (0.7 * df["exam_average"] + 0.3 * df["homework_score"]).round(2)
df["status"] = df["final_score"].apply(lambda x: "Pass" if x >= 60 else "Fail")

print(df)

print("\nPassed students:")
print(df[df["status"] == "Pass"][["name", "final_score"]])

print("\nSorted by final score:")
df = df.sort_values("final_score", ascending=False)
print(df[["name", "final_score", "status"]])

print("\nStatus count:")
print(df["status"].value_counts())

print("\nAverage final score by status:")
print(df.groupby("status")["final_score"].mean().round(2))

df.to_csv("student_report.csv", index=False)
print("\nSaved student_report.csv")


# Comparison and Reflection
#
# Procedural: the program is a list of steps with functions, loops and if statements.
# Easy to write and read for small tasks. Gets messy when the program grows because
# data and functions are separate and everything is shared.
#
# OOP: data and behaviour live together in classes (Student, Classroom).
# Good for bigger programs, easy to reuse and extend. Needs more code and planning,
# which feels like too much for a small script like this one.
#
# Functional: small pure functions, map/filter/reduce, no changing the original data.
# Fewer bugs from side effects and easy to test. Can be harder to read,
# especially with many lambdas, and Python is not fully built for this style.
#
# NumPy is useful for fast math on numbers without loops (averages, stats, masks).
# Pandas is useful for table data: adding columns, filtering, grouping and exporting
# to CSV. For real data analysis both are faster and shorter than plain Python.
