import csv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def calculate_revenue(quantity, price):
    return quantity * price


def get_top_product(df):
    revenue = df.groupby("Product")["Total_Sales"].sum()
    return revenue.idxmax()


# Part 2 - Python and NumPy
products = []
quantities = []
with open("sales.csv") as f:
    for row in csv.DictReader(f):
        products.append(row["Product"])
        quantities.append(int(row["Quantity"]))

print("Products:", products)

qty_per_product = {}
for p, q in zip(products, quantities):
    qty_per_product[p] = qty_per_product.get(p, 0) + q
print("Quantity per product:", qty_per_product)

qty = np.array(quantities)
print("Total quantity:", qty.sum())
print("Average quantity:", round(qty.mean(), 2))
print("Max quantity:", qty.max())
print("Min quantity:", qty.min())
print("Std deviation:", round(qty.std(), 2))
print("Indices with quantity > 5:", np.where(qty > 5)[0])

# Part 3 - Pandas
df = pd.read_csv("sales.csv")
print("\n", df.head())
df.info()
print(df.describe())

df["Total_Sales"] = calculate_revenue(df["Quantity"], df["Price"])

print("\nTotal revenue:", df["Total_Sales"].sum())
print("Top product:", get_top_product(df))

category_revenue = df.groupby("Category")["Total_Sales"].sum()
print("\nRevenue by category:\n", category_revenue)

region_revenue = df.groupby("Region")["Total_Sales"].sum()
print("\nBest region:", region_revenue.idxmax())

df = df.sort_values("Total_Sales", ascending=False)
print("\n", df)
df.to_csv("updated_sales.csv", index=False)

# Part 4 - Charts
product_revenue = df.groupby("Product")["Total_Sales"].sum().sort_values(ascending=False)

plt.figure(figsize=(8, 5))
plt.bar(product_revenue.index, product_revenue.values, color="steelblue")
plt.title("Total Revenue by Product")
plt.xlabel("Product")
plt.ylabel("Revenue ($)")
plt.tight_layout()
plt.savefig("bar_chart.png")
plt.close()

plt.figure(figsize=(6, 6))
plt.pie(category_revenue.values, labels=category_revenue.index, autopct="%1.1f%%", startangle=90)
plt.title("Revenue Share by Category")
plt.tight_layout()
plt.savefig("pie_chart.png")
plt.close()

plt.figure(figsize=(8, 5))
plt.hist(df["Total_Sales"], bins=6, color="seagreen", edgecolor="black")
plt.title("Distribution of Sales Revenue")
plt.xlabel("Revenue per sale ($)")
plt.ylabel("Number of sales")
plt.tight_layout()
plt.savefig("histogram.png")
plt.close()

print("\nCharts saved.")
